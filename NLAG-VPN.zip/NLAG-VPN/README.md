# NLAG-VPN

Modern Android WireGuard VPN client with **OriginOS 7–inspired liquid glass UI**.

## Features

- Built-in Portal free servers: 🇨🇦 Canada, 🇯🇵 Japan, 🇨🇭 Switzerland, 🇳🇱 Netherlands, 🇺🇸 United States
- Add your own WireGuard `.conf` files
- Liquid glass cards, spring / bounce animations, pulsing connect orb
- Jetpack Compose + Material 3
- Official WireGuard tunnel library (`com.wireguard.android:tunnel`)

## Design

Dark translucent surfaces, soft borders, bouncy scale on press, expanding rings while connecting — in the spirit of OriginOS 7 liquid glass.

## Build locally

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions

Push to `main`/`master` or run the workflow manually. The **NLAG-VPN-debug** artifact contains the APK.

## Notes

- Portal configs originally contain AmneziaWG obfuscation parameters. The app strips unknown keys so the standard WireGuard parser accepts them. If a server *requires* Amnezia, handshake may fail — use a full Amnezia-compatible client for those nodes, or paste a pure WireGuard config via “Add”.
- First connect requests Android VPN permission.
- Min SDK 26, target 35.

## Package

`com.nlag.vpn`
