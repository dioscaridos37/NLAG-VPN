package com.nlag.vpn.vpn

import android.app.Service
import android.content.Intent
import android.os.IBinder

/**
 * Optional foreground service stub. Actual tunnel is handled by
 * com.wireguard.android.backend.GoBackend$VpnService.
 */
class VpnConnectionService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }
}
