package com.nlag.vpn.data

data class Server(
    val id: String,
    val name: String,
    val countryCode: String,
    val flag: String,
    val configText: String,
    val isCustom: Boolean = false
)

object BuiltInServers {
    val list = listOf(
        Server(
            id = "ca-24",
            name = "Canada #24",
            countryCode = "CA",
            flag = "🇨🇦",
            configText = """
[Interface]
PrivateKey = MHJzhFTA2QIq7hBdIkDfTxfDC/45NGw18dlCD+ShnWc=
Address = 10.2.0.2/32, 2a07:b944::2:2/128
DNS = 10.2.0.1, 2a07:b944::2:1
MTU = 1420

[Peer]
PublicKey = hzVczgei46mNzEc1984x7fbszEJuq1GIlINPRRbUD3k=
Endpoint = 195.242.214.34:51820
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
""".trimIndent()
        ),
        Server(
            id = "jp-11",
            name = "Japan #11",
            countryCode = "JP",
            flag = "🇯🇵",
            configText = """
[Interface]
PrivateKey = MHJzhFTA2QIq7hBdIkDfTxfDC/45NGw18dlCD+ShnWc=
Address = 10.2.0.2/32, 2a07:b944::2:2/128
DNS = 10.2.0.1, 2a07:b944::2:1
MTU = 1420

[Peer]
PublicKey = 59gfAOFmOpTzfFjLxxa/hDXTFSC0d6fG9ujop0y4QF0=
Endpoint = 37.19.205.145:51820
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
""".trimIndent()
        ),
        Server(
            id = "ch-2",
            name = "Switzerland #2",
            countryCode = "CH",
            flag = "🇨🇭",
            configText = """
[Interface]
PrivateKey = MHJzhFTA2QIq7hBdIkDfTxfDC/45NGw18dlCD+ShnWc=
Address = 10.2.0.2/32, 2a07:b944::2:2/128
DNS = 10.2.0.1, 2a07:b944::2:1
MTU = 1420

[Peer]
PublicKey = 9nrcUUgwvjNU5Z+EBB0C2cbrhQ3dsCz+zSU83/eqGFY=
Endpoint = 138.199.6.177:51820
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
""".trimIndent()
        ),
        Server(
            id = "nl-88",
            name = "Netherlands #88",
            countryCode = "NL",
            flag = "🇳🇱",
            configText = """
[Interface]
PrivateKey = 0F6nxjM2Bc3ASt0gSLqNNGDeC4bPdqalq/7Cz7SdQEk=
Address = 10.2.0.2/32, 2a07:b944::2:2/128
DNS = 10.2.0.1, 2a07:b944::2:1
MTU = 1420

[Peer]
PublicKey = +TPg0y+6OBYFCOIoPc6JIGi06RWnWW9LntfWQdDOlik=
Endpoint = 89.39.104.165:51820
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
""".trimIndent()
        ),
        Server(
            id = "us-140",
            name = "United States #140",
            countryCode = "US",
            flag = "🇺🇸",
            configText = """
[Interface]
PrivateKey = 0F6nxjM2Bc3ASt0gSLqNNGDeC4bPdqalq/7Cz7SdQEk=
Address = 10.2.0.2/32, 2a07:b944::2:2/128
DNS = 10.2.0.1, 2a07:b944::2:1
MTU = 1420

[Peer]
PublicKey = VHJLuWC6jMC+05qL1ulLFBk1f5UpyCP7uzxxQhmwg0Q=
Endpoint = 194.180.34.11:51820
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
""".trimIndent()
        )
    )
}
