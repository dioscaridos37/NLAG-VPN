package com.nlag.vpn

import android.app.Application
import com.nlag.vpn.data.ServerRepository
import com.nlag.vpn.vpn.VpnManager

class NlagApp : Application() {
    lateinit var serverRepository: ServerRepository
        private set
    lateinit var vpnManager: VpnManager
        private set

    override fun onCreate() {
        super.onCreate()
        serverRepository = ServerRepository(this)
        vpnManager = VpnManager(this)
    }
}
