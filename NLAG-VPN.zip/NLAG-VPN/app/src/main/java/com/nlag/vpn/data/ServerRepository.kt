package com.nlag.vpn.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "nlag_prefs")

class ServerRepository(private val context: Context) {

    private val selectedIdKey = stringPreferencesKey("selected_server_id")
    private val customConfigsKey = stringSetPreferencesKey("custom_configs")

    val selectedServerId: Flow<String?> = context.dataStore.data.map { it[selectedIdKey] }

    suspend fun setSelectedServerId(id: String) {
        context.dataStore.edit { it[selectedIdKey] = id }
    }

    val customServers: Flow<List<Server>> = context.dataStore.data.map { prefs ->
        val set = prefs[customConfigsKey] ?: emptySet()
        set.mapNotNull { parseCustom(it) }
    }

    suspend fun addCustomServer(name: String, configText: String): Server {
        val id = "custom_${System.currentTimeMillis()}"
        val server = Server(
            id = id,
            name = name.ifBlank { "Custom ${id.takeLast(4)}" },
            countryCode = "XX",
            flag = "🌐",
            configText = configText.trim(),
            isCustom = true
        )
        context.dataStore.edit { prefs ->
            val current = prefs[customConfigsKey]?.toMutableSet() ?: mutableSetOf()
            current.add(serialize(server))
            prefs[customConfigsKey] = current
        }
        return server
    }

    suspend fun removeCustomServer(id: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[customConfigsKey]?.toMutableSet() ?: return@edit
            val filtered = current.filter { !it.startsWith("{\"id\":\"$id\"") }.toSet()
            prefs[customConfigsKey] = filtered
        }
    }

    suspend fun getAllServers(): List<Server> {
        val customs = customServers.first()
        return BuiltInServers.list + customs
    }

    suspend fun getServerById(id: String): Server? {
        return getAllServers().find { it.id == id }
    }

    private fun serialize(s: Server): String {
        return JSONObject().apply {
            put("id", s.id)
            put("name", s.name)
            put("countryCode", s.countryCode)
            put("flag", s.flag)
            put("configText", s.configText)
            put("isCustom", s.isCustom)
        }.toString()
    }

    private fun parseCustom(json: String): Server? {
        return try {
            val o = JSONObject(json)
            Server(
                id = o.getString("id"),
                name = o.getString("name"),
                countryCode = o.optString("countryCode", "XX"),
                flag = o.optString("flag", "🌐"),
                configText = o.getString("configText"),
                isCustom = true
            )
        } catch (e: Exception) {
            null
        }
    }
}
