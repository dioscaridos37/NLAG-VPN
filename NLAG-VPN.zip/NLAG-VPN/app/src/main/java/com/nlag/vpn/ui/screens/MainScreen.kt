package com.nlag.vpn.ui.screens

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nlag.vpn.data.Server
import com.nlag.vpn.ui.components.ConnectOrb
import com.nlag.vpn.ui.components.GlassButton
import com.nlag.vpn.ui.components.GlassCard
import com.nlag.vpn.ui.components.SectionTitle
import com.nlag.vpn.ui.theme.AccentGreen
import com.nlag.vpn.ui.theme.AccentPurple
import com.nlag.vpn.ui.theme.GlassBackground
import com.nlag.vpn.ui.theme.GlassBorder
import com.nlag.vpn.ui.theme.TextPrimary
import com.nlag.vpn.ui.theme.TextSecondary
import com.nlag.vpn.vpn.ConnectionState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    vm: MainViewModel = viewModel()
) {
    val state by vm.uiState.collectAsState()
    val context = LocalContext.current
    val activity = context as Activity
    val snackbar = remember { SnackbarHostState() }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        vm.onVpnPermissionResult(result.resultCode == Activity.RESULT_OK)
    }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0F0A1F),
                        GlassBackground,
                        Color(0xFF0A1220)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "NLAG-VPN",
                    color = TextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = { vm.openAddSheet() }) {
                    Icon(Icons.Rounded.Add, contentDescription = "Add", tint = TextPrimary)
                }
            }

            Spacer(Modifier.height(24.dp))

            // Status text
            AnimatedContent(
                targetState = state.connection,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "status"
            ) { conn ->
                val (title, color) = when (conn) {
                    is ConnectionState.Connected -> "Connected" to AccentGreen
                    is ConnectionState.Connecting -> "Connecting…" to AccentPurple
                    is ConnectionState.Error -> "Error" to Color(0xFFF87171)
                    else -> "Not connected" to TextSecondary
                }
                Text(
                    text = title,
                    color = color,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(Modifier.height(8.dp))

            Text(
                text = state.selected?.let { "${it.flag}  ${it.name}" } ?: "Select a server",
                color = TextSecondary,
                fontSize = 14.sp
            )

            Spacer(Modifier.height(32.dp))

            // Connect orb
            ConnectOrb(
                state = state.connection,
                onClick = { vm.toggleConnection(activity, permissionLauncher) }
            )

            Spacer(Modifier.height(28.dp))

            // Server selector card
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                onClick = { vm.openServerSheet() }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = state.selected?.flag ?: "🌐",
                        fontSize = 28.sp
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Server",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Text(
                            text = state.selected?.name ?: "Choose server",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Icon(
                        Icons.Rounded.ExpandMore,
                        contentDescription = null,
                        tint = TextSecondary
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Quick tip
            Text(
                text = "Tap the orb to connect. Add your own .conf via +",
                color = TextSecondary.copy(alpha = 0.7f),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        ) { data ->
            Snackbar(
                snackbarData = data,
                containerColor = Color(0xEE1E1B2E),
                contentColor = TextPrimary,
                shape = RoundedCornerShape(16.dp)
            )
        }
    }

    // Server list sheet
    if (state.showServerSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { vm.closeServerSheet() },
            sheetState = sheetState,
            containerColor = Color(0xFF12101C),
            contentColor = TextPrimary,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 32.dp)
            ) {
                SectionTitle("Servers")
                LazyColumn(
                    contentPadding = PaddingValues(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(state.servers, key = { it.id }) { server ->
                        ServerRow(
                            server = server,
                            selected = state.selected?.id == server.id,
                            onSelect = { vm.selectServer(server) },
                            onDelete = if (server.isCustom) {{ vm.deleteCustom(server) }} else null
                        )
                    }
                }
            }
        }
    }

    // Add custom sheet
    if (state.showAddSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        var name by remember { mutableStateOf("") }
        var conf by remember { mutableStateOf("") }
        ModalBottomSheet(
            onDismissRequest = { vm.closeAddSheet() },
            sheetState = sheetState,
            containerColor = Color(0xFF12101C),
            contentColor = TextPrimary,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .padding(bottom = 32.dp)
            ) {
                SectionTitle("Add Custom Config")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = glassFieldColors(),
                    shape = RoundedCornerShape(16.dp)
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = conf,
                    onValueChange = { conf = it },
                    label = { Text("Paste WireGuard .conf") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    colors = glassFieldColors(),
                    shape = RoundedCornerShape(16.dp)
                )
                Spacer(Modifier.height(20.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    GlassButton(
                        text = "Cancel",
                        onClick = { vm.closeAddSheet() },
                        primary = false,
                        modifier = Modifier.weight(1f)
                    )
                    GlassButton(
                        text = "Add",
                        onClick = { vm.addCustomConfig(name, conf) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun ServerRow(
    server: Server,
    selected: Boolean,
    onSelect: () -> Unit,
    onDelete: (() -> Unit)?
) {
    GlassCard(
        elevated = selected,
        onClick = onSelect,
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = server.flag, fontSize = 26.sp)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = server.name,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                if (server.isCustom) {
                    Text(
                        text = "Custom",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
            if (selected) {
                Icon(
                    Icons.Rounded.Check,
                    contentDescription = null,
                    tint = AccentGreen,
                    modifier = Modifier.size(22.dp)
                )
            }
            if (onDelete != null) {
                IconButton(onClick = onDelete) {
                    Icon(
                        Icons.Rounded.Delete,
                        contentDescription = "Delete",
                        tint = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun glassFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = AccentPurple,
    unfocusedBorderColor = GlassBorder,
    focusedLabelColor = AccentPurple,
    unfocusedLabelColor = TextSecondary,
    cursorColor = AccentPurple,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary
)
