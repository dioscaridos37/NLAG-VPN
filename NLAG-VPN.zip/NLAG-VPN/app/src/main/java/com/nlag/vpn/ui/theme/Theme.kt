package com.nlag.vpn.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// OriginOS 7 inspired liquid glass palette
val GlassBackground = Color(0xFF0A0A12)
val GlassSurface = Color(0x22FFFFFF)
val GlassSurfaceElevated = Color(0x33FFFFFF)
val GlassBorder = Color(0x44FFFFFF)
val AccentPurple = Color(0xFF7C5CFF)
val AccentPurpleLight = Color(0xFFA78BFA)
val AccentCyan = Color(0xFF22D3EE)
val AccentGreen = Color(0xFF34D399)
val AccentRed = Color(0xFFF87171)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)

private val DarkColorScheme = darkColorScheme(
    primary = AccentPurple,
    secondary = AccentCyan,
    tertiary = AccentPurpleLight,
    background = GlassBackground,
    surface = GlassBackground,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = AccentRed
)

@Composable
fun NLAGTheme(
    darkTheme: Boolean = true, // always dark glass
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
