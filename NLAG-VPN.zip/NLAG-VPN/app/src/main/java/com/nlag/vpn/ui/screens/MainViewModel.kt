package com.nlag.vpn.ui.screens

import android.app.Activity
import android.app.Application
import android.content.Intent
import androidx.activity.result.ActivityResultLauncher
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nlag.vpn.NlagApp
import com.nlag.vpn.data.Server
import com.nlag.vpn.vpn.ConnectionState
import com.nlag.vpn.vpn.VpnManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UiState(
    val servers: List<Server> = emptyList(),
    val selected: Server? = null,
    val connection: ConnectionState = ConnectionState.Disconnected,
    val showServerSheet: Boolean = false,
    val showAddSheet: Boolean = false,
    val message: String? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as NlagApp).serverRepository
    private val vpn: VpnManager = (app as NlagApp).vpnManager

    private val _showServerSheet = MutableStateFlow(false)
    private val _showAddSheet = MutableStateFlow(false)
    private val _message = MutableStateFlow<String?>(null)
    private val _selectedOverride = MutableStateFlow<Server?>(null)

    val uiState: StateFlow<UiState> = combine(
        repo.customServers,
        repo.selectedServerId,
        vpn.state,
        _showServerSheet,
        _showAddSheet,
        _message,
        _selectedOverride
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val customs = values[0] as List<Server>
        val selectedId = values[1] as String?
        val conn = values[2] as ConnectionState
        val sheet = values[3] as Boolean
        val add = values[4] as Boolean
        val msg = values[5] as String?
        val override = values[6] as Server?

        val all = com.nlag.vpn.data.BuiltInServers.list + customs
        val selected = override ?: all.find { it.id == selectedId } ?: all.firstOrNull()

        UiState(
            servers = all,
            selected = selected,
            connection = conn,
            showServerSheet = sheet,
            showAddSheet = add,
            message = msg
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState())

    init {
        viewModelScope.launch {
            // ensure a default selection
            val id = repo.selectedServerId.stateIn(viewModelScope, SharingStarted.Eagerly, null).value
            if (id == null) {
                repo.setSelectedServerId(com.nlag.vpn.data.BuiltInServers.list.first().id)
            }
        }
    }

    fun openServerSheet() { _showServerSheet.value = true }
    fun closeServerSheet() { _showServerSheet.value = false }
    fun openAddSheet() { _showAddSheet.value = true }
    fun closeAddSheet() { _showAddSheet.value = false }
    fun clearMessage() { _message.value = null }

    fun selectServer(server: Server) {
        viewModelScope.launch {
            repo.setSelectedServerId(server.id)
            _selectedOverride.value = server
            closeServerSheet()
            // if connected, reconnect to new server
            if (vpn.isConnected()) {
                vpn.disconnect()
                vpn.connect(server)
            }
        }
    }

    fun toggleConnection(activity: Activity, launcher: ActivityResultLauncher<Intent>) {
        viewModelScope.launch {
            val state = vpn.state.value
            when (state) {
                is ConnectionState.Connected, is ConnectionState.Connecting -> {
                    vpn.disconnect()
                }
                else -> {
                    val server = uiState.value.selected ?: return@launch
                    val prepare = vpn.prepareVpn(activity)
                    if (prepare != null) {
                        launcher.launch(prepare)
                    } else {
                        vpn.connect(server)
                    }
                }
            }
        }
    }

    fun onVpnPermissionResult(granted: Boolean) {
        if (!granted) {
            _message.value = "VPN permission is required"
            return
        }
        viewModelScope.launch {
            val server = uiState.value.selected ?: return@launch
            vpn.connect(server)
        }
    }

    fun addCustomConfig(name: String, configText: String) {
        viewModelScope.launch {
            try {
                if (!configText.contains("[Interface]") || !configText.contains("[Peer]")) {
                    _message.value = "Invalid WireGuard config"
                    return@launch
                }
                val server = repo.addCustomServer(name, configText)
                selectServer(server)
                closeAddSheet()
                _message.value = "Config added"
            } catch (e: Exception) {
                _message.value = e.message ?: "Failed to add config"
            }
        }
    }

    fun deleteCustom(server: Server) {
        if (!server.isCustom) return
        viewModelScope.launch {
            repo.removeCustomServer(server.id)
            if (uiState.value.selected?.id == server.id) {
                val first = com.nlag.vpn.data.BuiltInServers.list.first()
                selectServer(first)
            }
        }
    }
}
