package com.nlag.vpn.vpn

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.util.Log
import com.nlag.vpn.data.Server
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream

sealed class ConnectionState {
    data object Disconnected : ConnectionState()
    data object Connecting : ConnectionState()
    data class Connected(val serverName: String) : ConnectionState()
    data class Error(val message: String) : ConnectionState()
}

class VpnManager(private val context: Context) {

    private val backend: Backend = GoBackend(context)
    private val tunnel = VpnTunnel()

    private val _state = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    private var currentServer: Server? = null

    fun prepareVpn(activity: Activity): Intent? {
        return VpnService.prepare(activity)
    }

    suspend fun connect(server: Server) {
        withContext(Dispatchers.IO) {
            try {
                _state.value = ConnectionState.Connecting
                currentServer = server

                val cleaned = cleanConfig(server.configText)
                val config = Config.parse(ByteArrayInputStream(cleaned.toByteArray(Charsets.UTF_8)))

                backend.setState(tunnel, Tunnel.State.UP, config)
                _state.value = ConnectionState.Connected(server.name)
            } catch (e: Exception) {
                Log.e("VpnManager", "Connect failed", e)
                _state.value = ConnectionState.Error(e.message ?: "Connection failed")
            }
        }
    }

    suspend fun disconnect() {
        withContext(Dispatchers.IO) {
            try {
                backend.setState(tunnel, Tunnel.State.DOWN, null)
                currentServer = null
                _state.value = ConnectionState.Disconnected
            } catch (e: Exception) {
                Log.e("VpnManager", "Disconnect failed", e)
                _state.value = ConnectionState.Error(e.message ?: "Disconnect failed")
            }
        }
    }

    fun isConnected(): Boolean = _state.value is ConnectionState.Connected

    /**
     * Strip AmneziaWG / unknown keys so standard WireGuard Config parser accepts the file.
     * Portal servers often use Amnezia obfuscation; if handshake fails the server may require
     * a full Amnezia-compatible client.
     */
    private fun cleanConfig(raw: String): String {
        val allowedInterface = setOf(
            "PrivateKey", "Address", "DNS", "MTU", "ListenPort", "FwMark",
            "Table", "PreUp", "PostUp", "PreDown", "PostDown", "SaveConfig"
        )
        val allowedPeer = setOf(
            "PublicKey", "PresharedKey", "AllowedIPs", "Endpoint",
            "PersistentKeepalive", "Name"
        )
        val sb = StringBuilder()
        var section = ""
        for (line in raw.lines()) {
            val trimmed = line.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("#") || trimmed.startsWith(";")) {
                if (trimmed.startsWith("#") || trimmed.startsWith(";")) continue
                sb.appendLine()
                continue
            }
            if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
                section = trimmed.lowercase()
                sb.appendLine(trimmed)
                continue
            }
            val key = trimmed.substringBefore("=").trim()
            when {
                section.contains("interface") && key in allowedInterface -> sb.appendLine(trimmed)
                section.contains("peer") && key in allowedPeer -> sb.appendLine(trimmed)
                // skip Amnezia / unknown keys (S1..S4, Jc, Jmin, Jmax, H1..H4, I1, etc.)
            }
        }
        if (!sb.contains("PersistentKeepalive")) {
            // ensure keepalive for mobile
            val idx = sb.lastIndexOf("[Peer]")
            if (idx >= 0) {
                sb.appendLine("PersistentKeepalive = 25")
            }
        }
        return sb.toString()
    }
}
