package com.nlag.vpn.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.nlag.vpn.ui.theme.AccentCyan
import com.nlag.vpn.ui.theme.AccentGreen
import com.nlag.vpn.ui.theme.AccentPurple
import com.nlag.vpn.ui.theme.AccentRed
import com.nlag.vpn.vpn.ConnectionState
import kotlinx.coroutines.delay

@Composable
fun ConnectOrb(
    state: ConnectionState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "press"
    )

    val infinite = rememberInfiniteTransition(label = "rings")
    val ring1 by infinite.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "r1"
    )
    val ring2 by infinite.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, delayMillis = 600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "r2"
    )
    val alpha1 by infinite.animateFloat(
        initialValue = 0.5f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "a1"
    )
    val alpha2 by infinite.animateFloat(
        initialValue = 0.4f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, delayMillis = 600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "a2"
    )

    val isActive = state is ConnectionState.Connected || state is ConnectionState.Connecting
    val coreColor = when (state) {
        is ConnectionState.Connected -> AccentGreen
        is ConnectionState.Connecting -> AccentCyan
        is ConnectionState.Error -> AccentRed
        else -> AccentPurple
    }

    val pulse = remember { Animatable(1f) }
    LaunchedEffect(state) {
        if (state is ConnectionState.Connecting) {
            while (true) {
                pulse.animateTo(1.08f, spring(stiffness = Spring.StiffnessLow))
                pulse.animateTo(1f, spring(stiffness = Spring.StiffnessLow))
                delay(100)
            }
        } else {
            pulse.snapTo(1f)
        }
    }

    Box(
        modifier = modifier
            .size(200.dp)
            .scale(pressScale * pulse.value),
        contentAlignment = Alignment.Center
    ) {
        // Outer rings only when connecting / connected
        if (isActive) {
            Canvas(modifier = Modifier.size(200.dp)) {
                val center = Offset(size.width / 2, size.height / 2)
                val maxR = size.minDimension / 2
                drawCircle(
                    color = coreColor.copy(alpha = alpha1),
                    radius = maxR * ring1,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
                drawCircle(
                    color = coreColor.copy(alpha = alpha2),
                    radius = maxR * ring2,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }

        // Glass core
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            coreColor.copy(alpha = 0.85f),
                            coreColor.copy(alpha = 0.45f),
                            Color(0x22000000)
                        )
                    )
                )
                .clickable(
                    interactionSource = interaction,
                    indication = null,
                    onClick = onClick
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.PowerSettingsNew,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(48.dp)
            )
        }
    }
}
