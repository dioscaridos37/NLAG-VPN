package com.nlag.vpn.vpn

import com.wireguard.android.backend.Tunnel

class VpnTunnel(private val name: String = "nlag-tunnel") : Tunnel {
    override fun getName(): String = name
    override fun onStateChange(newState: Tunnel.State) {
        // State changes are observed via backend callbacks / manager
    }
}
