-keep class com.wireguard.** { *; }
-dontwarn com.wireguard.**
-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}
